package com.example.timewallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

// ---------- Sky colour keyframes (hour of day -> colour) ----------
private val HOURS = floatArrayOf(0f, 4.5f, 6f, 7.5f, 12f, 16.5f, 18f, 19.5f, 21f, 24f)
private val SKY_TOP = intArrayOf(
    c("#050A1E"), c("#0E1633"), c("#4B5C9E"), c("#3D8FE0"), c("#1C74E0"),
    c("#3A86D8"), c("#3A3470"), c("#141A45"), c("#070C26"), c("#050A1E")
)
private val SKY_BOTTOM = intArrayOf(
    c("#111B3D"), c("#3B3563"), c("#FFB07A"), c("#A9D8FF"), c("#7CC4FF"),
    c("#FFD9A0"), c("#FF7A50"), c("#6B3F7E"), c("#17224A"), c("#111B3D")
)

private fun c(hex: String) = Color.parseColor(hex)
private const val PI_F = PI.toFloat()
private const val TWO_PI_F = (2 * PI).toFloat()

private fun smooth(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3 - 2 * t)
}

private fun bump(x: Float, center: Float, width: Float): Float {
    val d = (x - center) / width
    return exp(-d * d)
}

private fun lerpColor(a: Int, b: Int, f: Float): Int {
    val t = f.coerceIn(0f, 1f)
    return Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}

private fun withAlpha(color: Int, alpha: Int) =
    (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

private fun sampleSky(arr: IntArray, h: Float): Int {
    for (i in 0 until HOURS.size - 1) {
        if (h >= HOURS[i] && h <= HOURS[i + 1]) {
            val f = smooth(0f, 1f, (h - HOURS[i]) / (HOURS[i + 1] - HOURS[i]))
            return lerpColor(arr[i], arr[i + 1], f)
        }
    }
    return arr.last()
}

// ---------- Scene objects ----------
private class Star(val x: Float, val y: Float, val r: Float, val phase: Float)
private class Cloud(var x: Float, val y: Float, val scale: Float, val speed: Float)
private class Bird(var x: Float, var y: Float, val speed: Float, val size: Float, val phase: Float)
private class Firefly(val x: Float, val y: Float, val phase: Float, val speed: Float)

// cloud puffs: dx, dy, radius (in 1080px-wide units)
private val PUFFS = arrayOf(
    floatArrayOf(0f, 0f, 38f), floatArrayOf(42f, 8f, 30f), floatArrayOf(-44f, 10f, 28f),
    floatArrayOf(18f, -18f, 30f), floatArrayOf(-18f, -12f, 25f), floatArrayOf(76f, 16f, 20f),
    floatArrayOf(-74f, 18f, 20f)
)

class TimeWallpaperService : WallpaperService() {

    companion object {
        /** Set to true to watch a whole 24h day play in 60 seconds (handy for testing). */
        const val DEMO_MODE = false
        const val DEMO_DAY_MS = 60_000L
        /** Normal mode redraws only this often (ms) while the wallpaper is visible. */
        const val REDRAW_MS = 60_000L
    }

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private val frame = object : Runnable { override fun run() = drawFrame() }

        private val dp = resources.displayMetrics.density
        private var w = 1080f
        private var h = 1920f
        private var visible = false
        private val time = 0f // fixed: nothing animates
        private var lastFrame = SystemClock.uptimeMillis()

        // paints (reused every frame)
        private val skyPaint = Paint()
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val path = Path()
        private val rect = RectF()

        private val rnd = Random(42)
        private val stars = List(150) {
            Star(rnd.nextFloat(), rnd.nextFloat() * 0.62f, 0.6f + rnd.nextFloat() * 1.6f, rnd.nextFloat() * TWO_PI_F)
        }
        private val clouds = List(6) {
            Cloud(rnd.nextFloat() * 1.4f - 0.2f, 0.07f + rnd.nextFloat() * 0.33f,
                0.7f + rnd.nextFloat() * 0.9f, 0.004f + rnd.nextFloat() * 0.008f)
        }
        private val birds = List(4) { i ->
            Bird(0.15f + i * 0.17f, 0.12f + rnd.nextFloat() * 0.2f,
                0.05f + rnd.nextFloat() * 0.03f, 10f + rnd.nextFloat() * 6f, rnd.nextFloat() * TWO_PI_F)
        }
        private val fireflies = List(20) {
            Firefly(rnd.nextFloat(), 0.76f + rnd.nextFloat() * 0.2f, rnd.nextFloat() * TWO_PI_F, 0.5f + rnd.nextFloat())
        }

        // ---------------- lifecycle ----------------
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width.toFloat(); h = height.toFloat()
            drawFrame()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(frame)
            if (isVisible) {
                lastFrame = SystemClock.uptimeMillis()
                drawFrame()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: IllegalArgumentException) {}
            }
            handler.removeCallbacks(frame)
            if (visible) handler.postDelayed(frame, if (DEMO_MODE) 50L else REDRAW_MS)
        }

        private fun currentHour(): Float {
            if (DEMO_MODE) {
                return (SystemClock.elapsedRealtime() % DEMO_DAY_MS) / DEMO_DAY_MS.toFloat() * 24f
            }
            val cal = Calendar.getInstance()
            return cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f + cal.get(Calendar.SECOND) / 3600f
        }

        // ---------------- rendering ----------------
        private fun render(cv: Canvas) {
            val hour = currentHour()
            val sunHeight = sin(TWO_PI_F * (hour - 6f) / 24f)           // -1..1, 0 at 6:00 and 18:00
            val daylight = smooth(-0.15f, 0.25f, sunHeight)              // 0 night .. 1 day
            val dark = 1f - daylight
            val sunset = max(bump(hour, 6.3f, 0.8f), bump(hour, 18.2f, 0.9f))
            val horizon = h * 0.72f

            drawSky(cv, hour, horizon, sunset)
            if (dark > 0.05f) drawStars(cv, dark)
            drawMoon(cv, hour, horizon)
            drawSun(cv, hour, horizon, daylight)
            drawClouds(cv, hour, dark, sunset)
            if (daylight > 0.3f) drawBirds(cv, daylight)
            drawLandscape(cv, dark, sunset)
            if (dark > 0.4f) drawFireflies(cv, dark)
        }

        private fun drawSky(cv: Canvas, hour: Float, horizon: Float, sunset: Float) {
            skyPaint.shader = LinearGradient(
                0f, 0f, 0f, h * 0.78f,
                sampleSky(SKY_TOP, hour), sampleSky(SKY_BOTTOM, hour), Shader.TileMode.CLAMP
            )
            cv.drawRect(0f, 0f, w, h, skyPaint)

            // warm horizon band at sunrise / sunset
            if (sunset > 0.15f) {
                val warm = c("#FF8A4C")
                skyPaint.shader = LinearGradient(
                    0f, horizon - h * 0.28f, 0f, horizon,
                    withAlpha(warm, 0), withAlpha(warm, (sunset * 150).toInt()), Shader.TileMode.CLAMP
                )
                cv.drawRect(0f, horizon - h * 0.28f, w, horizon, skyPaint)
            }
        }

        private fun drawStars(cv: Canvas, dark: Float) {
            fill.shader = null
            for (s in stars) {
                val twinkle = 0.55f + 0.45f * sin(time * 2f + s.phase)
                fill.color = withAlpha(Color.WHITE, (dark * twinkle * 255).toInt())
                cv.drawCircle(s.x * w, s.y * h, s.r * dp, fill)
            }
        }

        private fun drawSun(cv: Canvas, hour: Float, horizon: Float, daylight: Float) {
            val t = (hour - 6f) / 12f
            if (t < -0.2f || t > 1.2f) return
            val sx = w * (0.12f + 0.76f * t)
            val sy = horizon - sin(PI_F * t) * h * 0.5f
            val low = 1f - sin(PI_F * t.coerceIn(0f, 1f))               // 0 at noon .. 1 at horizon
            val col = lerpColor(c("#FFF4B0"), c("#FF8A3D"), low.pow(1.5f))
            val r = w * 0.07f

            // glow – biggest and brightest around midday ("sunny")
            val glowR = w * (0.30f + 0.18f * (1f - low))
            glowPaint.shader = RadialGradient(
                sx, sy, glowR, withAlpha(col, 160), withAlpha(col, 0), Shader.TileMode.CLAMP
            )
            cv.drawCircle(sx, sy, glowR, glowPaint)

            // rotating rays
            if (daylight > 0.3f) {
                stroke.strokeWidth = 3f * dp
                val rays = 14
                for (i in 0 until rays) {
                    val a = time * 0.15f + i * TWO_PI_F / rays
                    val len = r * (1.9f + 0.3f * sin(time * 2f + i))
                    stroke.color = withAlpha(col, (90 * (1f - low * 0.6f)).toInt())
                    cv.drawLine(
                        sx + kotlin.math.cos(a) * r * 1.4f, sy + sin(a) * r * 1.4f,
                        sx + kotlin.math.cos(a) * len, sy + sin(a) * len, stroke
                    )
                }
            }
            fill.shader = null
            fill.color = col
            cv.drawCircle(sx, sy, r, fill)
        }

        private fun drawMoon(cv: Canvas, hour: Float, horizon: Float) {
            var t = ((((hour - 18f) % 24f) + 24f) % 24f) / 12f
            if (t > 1.5f) t -= 2f
            if (t < -0.2f || t > 1.2f) return
            val mx = w * (0.12f + 0.76f * t)
            val my = horizon - sin(PI_F * t) * h * 0.45f
            val r = w * 0.055f
            val moon = c("#F4F1DE")

            glowPaint.shader = RadialGradient(
                mx, my, r * 4.5f, withAlpha(moon, 90), withAlpha(moon, 0), Shader.TileMode.CLAMP
            )
            cv.drawCircle(mx, my, r * 4.5f, glowPaint)
            fill.shader = null
            fill.color = moon
            cv.drawCircle(mx, my, r, fill)
            fill.color = withAlpha(c("#B9B6A0"), 140)                    // craters
            cv.drawCircle(mx - r * 0.3f, my - r * 0.25f, r * 0.22f, fill)
            cv.drawCircle(mx + r * 0.35f, my + r * 0.1f, r * 0.16f, fill)
            cv.drawCircle(mx - r * 0.05f, my + r * 0.45f, r * 0.12f, fill)
        }

        private fun drawClouds(cv: Canvas, hour: Float, dark: Float, sunset: Float) {
            var col = lerpColor(Color.WHITE, c("#FFB38A"), sunset)
            col = lerpColor(col, c("#2A3358"), dark)
            val alpha = (235 - 85 * dark).toInt()
            val u = w / 1080f
            fill.shader = null
            fill.color = withAlpha(col, alpha)
            for (cl in clouds) {
                val px = (((cl.x + hour * cl.speed * 8f) % 1.6f) + 1.6f) % 1.6f - 0.3f
                val cx = px * w
                val cy = cl.y * h
                val s = u * cl.scale
                for (p in PUFFS) cv.drawCircle(cx + p[0] * s, cy + p[1] * s, p[2] * s, fill)
                rect.set(cx - 90 * s, cy + 6 * s, cx + 90 * s, cy + 40 * s)
                cv.drawRoundRect(rect, 20 * s, 20 * s, fill)
            }
        }

        private fun drawBirds(cv: Canvas, daylight: Float) {
            stroke.strokeWidth = 2.2f * dp
            stroke.color = withAlpha(c("#2B2B3A"), (170 * daylight).toInt())
            for (b in birds) {
                val bx = b.x * w
                val by = b.y * h
                val sz = b.size * dp
                val flap = 0.5f
                path.reset()
                path.moveTo(bx - sz, by + flap * sz * 0.6f)
                path.quadTo(bx - sz * 0.4f, by - sz * 0.3f, bx, by)
                path.quadTo(bx + sz * 0.4f, by - sz * 0.3f, bx + sz, by + flap * sz * 0.6f)
                cv.drawPath(path, stroke)
            }
        }

        // ---------------- hills, trees, little house ----------------
        private fun hillY(x: Float, base: Float, amp: Float, freq: Float, phase: Float): Float =
            base + amp * sin(x * freq + phase) + amp * 0.5f * sin(x * freq * 2.3f + phase * 1.7f)

        private fun drawHills(cv: Canvas, base: Float, amp: Float, freq: Float, phase: Float, color: Int) {
            path.reset()
            path.moveTo(0f, h)
            var x = 0f
            val step = w / 40f
            while (x <= w + step) {
                path.lineTo(x, hillY(x, base, amp, freq, phase))
                x += step
            }
            path.lineTo(w, h)
            path.close()
            fill.shader = null
            fill.color = color
            cv.drawPath(path, fill)
        }

        private fun drawLandscape(cv: Canvas, dark: Float, sunset: Float) {
            val warmTint = c("#7A4A4A")
            val far = lerpColor(lerpColor(c("#7DBB6A"), c("#142238"), dark), warmTint, sunset * 0.25f)
            val near = lerpColor(lerpColor(c("#4E9A45"), c("#0A1424"), dark), warmTint, sunset * 0.2f)
            val freq1 = TWO_PI_F / w * 1.1f
            val freq2 = TWO_PI_F / w * 1.3f

            drawHills(cv, h * 0.76f, h * 0.03f, freq1, 0.6f, far)
            drawHills(cv, h * 0.855f, h * 0.025f, freq2, 1.0f, near)

            // pine trees
            val tree = lerpColor(c("#2F7A3E"), c("#0B1A1C"), dark)
            val trunk = lerpColor(c("#6B4A2F"), c("#120E12"), dark)
            for (tx in floatArrayOf(0.60f, 0.70f, 0.90f, 0.05f)) {
                val x = tx * w
                drawPine(cv, x, hillY(x, h * 0.855f, h * 0.025f, freq2, 1.0f) + 6f, h * 0.075f, tree, trunk)
            }

            // little house whose window lights up at night
            val hx = w * 0.26f
            val hy = hillY(hx, h * 0.855f, h * 0.025f, freq2, 1.0f) + 8f
            val hw = w * 0.13f
            val hh = w * 0.075f
            fill.color = lerpColor(c("#D9A06B"), c("#2A2030"), dark)
            rect.set(hx - hw / 2, hy - hh, hx + hw / 2, hy)
            cv.drawRect(rect, fill)
            fill.color = lerpColor(c("#9A3F30"), c("#1A1224"), dark)
            path.reset()
            path.moveTo(hx - hw * 0.62f, hy - hh)
            path.lineTo(hx, hy - hh * 1.65f)
            path.lineTo(hx + hw * 0.62f, hy - hh)
            path.close()
            cv.drawPath(path, fill)
            val ww = hw * 0.22f
            rect.set(hx - ww / 2, hy - hh * 0.75f, hx + ww / 2, hy - hh * 0.75f + ww)
            if (dark > 0.35f) {
                val lamp = c("#FFD27A")
                glowPaint.shader = RadialGradient(
                    hx, rect.centerY(), ww * 2.4f, withAlpha(lamp, (dark * 120).toInt()), withAlpha(lamp, 0), Shader.TileMode.CLAMP
                )
                cv.drawCircle(hx, rect.centerY(), ww * 2.4f, glowPaint)
                fill.color = withAlpha(lamp, (dark * 255).toInt())
            } else {
                fill.color = c("#8FC3E8")
            }
            cv.drawRect(rect, fill)
        }

        private fun drawPine(cv: Canvas, x: Float, baseY: Float, height: Float, treeCol: Int, trunkCol: Int) {
            fill.color = trunkCol
            cv.drawRect(x - height * 0.04f, baseY - height * 0.18f, x + height * 0.04f, baseY, fill)
            fill.color = treeCol
            for (i in 0..2) {
                val top = baseY - height + i * height * 0.24f
                val bottom = top + height * 0.52f
                val half = height * (0.2f + 0.08f * i)
                path.reset()
                path.moveTo(x, top)
                path.lineTo(x - half, bottom)
                path.lineTo(x + half, bottom)
                path.close()
                cv.drawPath(path, fill)
            }
        }

        // ---------------- night extras ----------------
        private fun drawFireflies(cv: Canvas, dark: Float) {
            for (f in fireflies) {
                val fx = (f.x + sin(time * 0.3f * f.speed + f.phase) * 0.03f) * w
                val fy = (f.y + sin(time * 0.5f * f.speed + f.phase * 2f) * 0.015f) * h
                val pulse = 0.5f + 0.5f * sin(time * 2f * f.speed + f.phase)
                val a = (dark * pulse * 255).toInt()
                val col = c("#E8FF7A")
                glowPaint.shader = RadialGradient(
                    fx, fy, 9f * dp, withAlpha(col, a), withAlpha(col, 0), Shader.TileMode.CLAMP
                )
                cv.drawCircle(fx, fy, 9f * dp, glowPaint)
                fill.shader = null
                fill.color = withAlpha(Color.WHITE, a)
                cv.drawCircle(fx, fy, 1.5f * dp, fill)
            }
        }
    }
}
